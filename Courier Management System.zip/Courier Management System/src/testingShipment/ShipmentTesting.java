package testingShipment;

import static org.junit.Assert.*;

import org.junit.Test;

import CMS.BLL.courier.Shipment;
import CMS.UIL.model.RateModel;

import java.sql.Date;
public class ShipmentTesting {

	@Test
	public void test() {
		
		Shipment s=new Shipment();
		s.setCID("C00001");
		s.setDeliveredBy("Mehtab");
		s.setDeliveredOn(new Date(0));
		s.setSID("S00001");
		s.setVehicleNumber("VIP001");
		assertEquals(s.getCID(),"C00001");
		assertEquals(s.getDeliveredBy(),"Mehtab");
		assertEquals(s.getSID(),"S00001");
		assertEquals(s.getDeliveredOn(),new Date(0));
		assertEquals(s.getVehicleNumber(),"VIP001");
		
		RateModel r=new RateModel("0001","Teerath ", "Kumar","Tharparkar");
		r.setAll("0001", "Teerath", "Kumar","Tharparkar");
		r.setFID("F00001");
		
	}

}
