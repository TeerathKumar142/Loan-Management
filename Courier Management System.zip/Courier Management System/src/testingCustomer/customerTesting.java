package testingCustomer;

import static org.junit.Assert.*;

import org.junit.Test;

import CMS.BLL.core.Customer;

public class customerTesting {

	@Test
	public void test() {
		Customer testCus=new Customer();
		testCus.setStatus(true);
		testCus.setAll("Teerath", "Kumar", "G-10 Markaz, Islamabad", "03352378242", "443031234556789", "FAST");
		testCus.setAll("01234","Teerath", "Kumar", "G-10 Markaz, Islamabad", "03352378242", "443031234556789", "FAST");
		testCus.setJoiningDate("2018-03-21");
		testCus.initAll("01234", "Teerath", "Kumar", "G-10 Markaz, Islamabad", "03352378242", "443031234556789", "FAST");
		testCus.SetSwap(true);
		testCus.setAll("Teerath", "Kumar", "G-10 Markaz, Islamabad", "03352378242", "443031234556789", "FAST");
		testCus.initAll("01234", "Teerath", "Kumar", "G-10 Markaz, Islamabad", "03352378242", "443031234556789", "FAST");
		assertEquals(testCus.getAddress(),"G-10 Markaz, Islamabad");
		assertEquals(testCus.getCID(),"01234");
		assertEquals(testCus.getCNIC(),"443031234556789");
		assertEquals(testCus.getContactNumber(),"03352378242");
		assertEquals(testCus.getFName(),"Teerath");
		assertEquals(testCus.getLName(),"Kumar");
		assertEquals(testCus.getOrganization(),"FAST");
		assertEquals(testCus.getStatus(),true);
		System.err.println(testCus.generateID());
		assertEquals(testCus.generateID(),"C000009");
	    testCus.SetSwap(false);
	    assertEquals(testCus.generateID(),"C000001");
		assertEquals(testCus.insertValue(),"('01234', 'Teerath', 'Kumar', 'G-10 Markaz, Islamabad', '03352378242', '443031234556789', '2018-03-21', 'FAST',1)");
		assertEquals(testCus.getJoiningDate(),"2018-03-21");
		assertEquals(testCus+"","01234,Teerath', 'Kumar', 'G-10 Markaz, Islamabad', '03352378242', '443031234556789', '21-03-2018,FAST");
		
	}

}
