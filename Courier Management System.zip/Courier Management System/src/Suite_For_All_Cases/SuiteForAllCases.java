package Suite_For_All_Cases;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import testingAccount.accountTesting;
import testingAdmin.testingAdmin;
import testingCustomer.customerTesting;
import testingShipment.ShipmentTesting;

import static org.junit.Assert.*;

import org.junit.Test;
@RunWith(Suite.class)

@Suite.SuiteClasses({ 
   accountTesting.class ,testingAdmin.class,
   customerTesting.class,ShipmentTesting.class
})
public class SuiteForAllCases {

}
