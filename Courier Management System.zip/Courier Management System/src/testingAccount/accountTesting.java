package testingAccount;

import static org.junit.Assert.*; 
import CMS.BLL.controller.SystemController;
import CMS.BLL.core.*;

public class accountTesting {

	@org.junit.Test
	public void test() {
		Account a=new Account();
		a.setAll("teerathkumar23@yahoo.com", "Pakistan");
		assertEquals("Password Authenticated...1",a.getPassword(),"Pakistan");
		assertEquals("Mail Authentiated ",a.getUserID(),"teerathkumar23@yahoo.com");
		assertEquals("Admin Account Verified", a.validateAccount("A000003","lahore")+"","Teerath,Kumar,G-10 Markaz Islamabad,03471386120,44303123456,1996-06-04");
        System.err.println(a.validateAccount("M000003", "KarachiKings")+"");
		assertEquals("Employee Account Verified ", a.validateAccount("E000009", "MultanSultan")+"", "E000009,Akash', 'Kumar', 'Diplo', '03323881213', '3520288854061', '2016-03-18,receptionist,BS(CS), null ,15000.0,F000005");
		assertEquals("Manager Account Verified ", a.validateAccount("M000003", "KarachiKings")+"", "Nilesh,Kumar,Larkana,03323881213,3520288854061,1985-09-24,M000003,BBA,75000.0,F000003");
		assertEquals("Employee Account not Verified ", a.validateAccount("E000009", "MuultaNSultaN"), null);
		assertEquals("Admin Account not Verified", a.validateAccount("A000005","Islamabaad"),null);
		assertEquals("Manager Account not Verified ", a.validateAccount("M000003","Karachi"  ), null);
		assertEquals("SQL error ", a.validateAccount("'M000003'", "KarachiKings"), 1064);
		assertEquals("Email and Password", a.insertValues(),"('teerathkumar23@yahoo.com','Pakistan')");	 
		assertEquals("Email , Password", a+"","teerathkumar23@yahoo.com,Pakistan");	 
	    
	}

}
