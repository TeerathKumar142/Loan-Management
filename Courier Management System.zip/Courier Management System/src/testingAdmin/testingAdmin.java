package testingAdmin;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import org.junit.Test;

import CMS.BLL.core.*;
import CMS.BLL.courier.Courier;
import CMS.BLL.courier.Rate;
import CMS.BLL.courier.RegisteredCourier;
import CMS.BLL.courier.UnRegisteredCourier;
import CMS.BLL.franchise.*;
import CMS.UIL.model.CourierModel;
import CMS.UIL.model.CustomerModel;
import CMS.UIL.model.EmployeeModel;
import CMS.UIL.model.FranchiseModel;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class testingAdmin {

	@Test
	public void test() {
		
		Admin a=new Admin();
		a.setAll("E000001", "Teerath", "Kumar", "G-10 Markaz", "03352378142", "44303123456789", "21-03-1998", 55000.0);
		assertEquals(a.getAddress(),"G-10 Markaz");
		assertEquals(a.getCNIC(),"44303123456789");
		assertEquals(a.getFName(),"Teerath");
		assertEquals(a.getLName(),"Kumar");
		assertEquals(a.getContactNumber(),"03352378142");
		assertEquals(a.getBasicSalary(),(55000.0),0);
		assertEquals(a.getDate_Of_Birth(), "21-03-1998");
		assertEquals(a.getID(),"E000001");
		Calendar calendar = Calendar.getInstance();
		java.util.Date currentDate = calendar.getTime();
		java.sql.Date dat=new java.sql.Date(currentDate.getTime());
		
		//Manager
		Manager m =new Manager();
		m.setAll("M00010","Teerath", "Kumar", "G-10 Markaz", "03352378142", "3520288854061", "1990-10-25", 55000.0 , "BS", "K000001");
		m.setAll("Teerath", "Kumar", "G-10 Markaz", "03352378142", "3520288854061", "1990-10-25", 55000.0 , "BS", "K000001");
		String mid=m.getMID();
		m.setJoiningDate(dat);
		assertEquals(a.addManager(m),true);
		assertEquals(a.getManager(mid)+"","M000011,Teerath Kumar,G-10 Markaz,3520288854061,1990-10-25,BS");
		m.SetMID("M00001");
		assertEquals(m.getStatus(),true);
		assertEquals(m+"","Teerath,Kumar,G-10 Markaz,03352378142,3520288854061,1990-10-25,M00001,BS,55000.0,K000001");
		assertEquals(m.getJoiningDate(),dat);
		assertEquals(m.getFID(),"K000001");
		assertEquals(m.generateMID(),"M000011");
		m.setSwap(false);
		assertEquals(m.generateMID(),"M000000");
		m.setAll("Teerath", "Kumar", "G-10 Markaz", "03352378142", "3520288854061", "1990-10-25", 55000.0 , "BS", "K000001");
		
		
		assertEquals(a.updateManager(m),1);
		assertEquals(a.fireManager(mid),true);
		assertEquals(a.fireManager(mid),false);
		assertEquals(a.getManagerList().size()>0,true);
		assertEquals(a.getFranchiseList().size()>0,true);
		assertEquals(a.getList("Manager", "MID").size()>0,true);
		assertEquals(a.getAllocatedAllowancesList().size()>0, true);
		assertEquals(a.retreieveFranchiseList().size()>0,true);
		assertEquals(a.retrieveFranchiseList().size()>0,true);
		ArrayList<String> id=new ArrayList();
		id.add("0006");
		
		Franchise f=new Franchise();
		f.setAll("F000001", "G-10 Markaz Branch", "Good one", "G-10 MArkaz", "03352378242");
		ArrayList<String> allw=new ArrayList();
		allw.add("Food");
		ArrayList<String> ids=new ArrayList();
		ids.add("F00010");
		f.setAllowances(allw );
		assertEquals(a.getFranchiseList().size()>0, true);
		assertEquals(a.getAllocatedAllowancesList().size()>0,true);
		assertEquals(a.AllowancesList().size()>0,true);
		assertEquals(a.getRegCourierList().size()>0, true);
		assertEquals(a.getEmployeeIDList("E00001").size()>0,false);
		assertEquals(a.getRegEmployeeList("F00001").size()>0,false);
		assertEquals(a.getFranchiseList().size()>0,true);
		assertEquals(a.FranchiseList().size()>0,false);
		 
		Account ac=new Account();
		ac.setAll("E00010","teerath");
		assertEquals(f.addAccount(ac),1);
		f.deleteAccount();
		assertEquals(m.addAccount(ac),true);
		assertEquals(m.updateAccount(ac),true);
		assertEquals(m.RemoveAccount(ac.getUserID()),true);
		
		
		
		Customer cu=new Customer();
		cu.initAll("C00008","Teerath", "Kumar","G-10 Markaz","03352378242","3520288854061","FAST");
		cu.setJoiningDate("2018-03-21");
		f.addCustomer(cu);
		
		assertEquals(m.addCustomer(cu),false);
		assertEquals(m.updateCutomer(cu),true);
		
		
		CustomerModel Cmodel=new CustomerModel(cu.getCID(), cu.getFName(), cu.getLName(), cu.getAddress(), cu.getContactNumber(), cu.getCNIC(), cu.getJoiningDate(), cu.getOrganization());
		Cmodel.setAll(cu.getFName(), cu.getLName(), cu.getAddress(), cu.getContactNumber(), cu.getCNIC(), cu.getOrganization());
		Cmodel.setStatus(true);
		assertEquals(m.deleteCustomer(Cmodel),true);
		
		
		
		Allowance alw=new Allowance();
		alw.setAll("Food", "Medical", 150000);
		assertEquals(alw.getAmount(),150000,0);
		assertEquals(alw.getDescription(),"Food");
		assertEquals(alw.getType(),"Medical");
		f.addAllowance(alw);
		assertEquals(m.RemoveAllowance(alw.getAllID()),true);
		assertEquals(m.addAllowance(alw),true);
		assertEquals(m.updateAllowance(alw),true);
		assertEquals(m.RemoveAllowance(alw.getAllID()),true);
		assertEquals(alw.generateID(),"0092");
		alw.setSwap(false);
		assertEquals(alw.generateID(),"0001");
		assertEquals(alw+"","0092,Food,Medical,150000.0");
		alw.setAll("0001", "For study", "Pending", 12000.0);
		
		m.setStatus(true);
		assertEquals(m.getCustomerList().size()>0,true);
		assertEquals(m.getList("Employee", "EID").size()>0,true);
		assertEquals(m.getRegEmployeeList("F000003").size()>0,true);
		assertEquals(m.getAllowanceList().size()>0,true);
		
		
		EmployeeModel Emodel=new EmployeeModel("E0001", "HR Dept", "Department", "G-10 Islamabad", "0232263232", "1234567890123","1996-02-12", "Manager", "BS", "Manager", "12000", "F00010");		
		Emodel.setFranchiseName("Islamabad");
		Emodel.setStatus(true);
		Emodel.updateSalary("15000");
		Emodel.setAll("HR Dept", "Department", "G-10 Islamabad", "0232263232", "1234567890123","New", "Manager", "BS", "Manager", "12000");		
		Emodel.updateDesignation("Manager");
		assertEquals(Emodel.toString(),Emodel+"");
		m.updateEmployee(Emodel);
		
		Employee e=new Employee();
		e.setAll("E00010", "Teerath", "Kumar","G-10 Markaz","03352378242","3520288854061","1996-02-17","FAST", "Employee" , 55000);
		e.setAll("Teerath", "Kumar","G-10 Markaz","03352378242","3520288854061","1996-02-17","FAST", "Employee" , 55000);
		assertEquals(m.addEmployee(e),true);
		assertEquals(m.updateEmployee(e),1);
		assertEquals(m.fireEmployee(e.getEID()),true);
		assertEquals(m.fireEmployee(e.getEID()),false);
		assertEquals(e.getAddress(),"G-10 Markaz");
		assertEquals(e.getBasicSalary(),55000,0);
		assertEquals(e.getCNIC(),"3520288854061");
		assertEquals(e.getContactNumber(),"03352378242");
		assertEquals(e.getDate_Of_Birth(),"1996-02-17");
		assertEquals(e.getDesignation(),"Employee");
		assertEquals(e.getFName(),"Teerath");
		assertEquals(e.getQualification(),"FAST");
		assertEquals(e.getDesignation(),"Employee");
        assertEquals(f.getAllowances().size()>0, true);
		assertEquals(e+"","E000011,Teerath', 'Kumar', 'G-10 Markaz', '03352378242', '3520288854061', '1996-02-17,Employee,FAST, null ,55000.0,null");
        
		RegisteredCourier rc=new RegisteredCourier();
        rc.setAll("C00001", "Teerath", "G-10 Markaz","03352378242", "2007-07-12", 1200.0, "gift", 15, "1", "Mehtab", "C00002");
        rc.setAll( "Teerath", "G-10 Markaz","03352378242", 1200.0, "gift", 15, "Mehtab");
        assertEquals(rc.getCID(),"C00001");
        assertEquals(rc.getCustomerID(),"C00002");
        assertEquals(rc.getPrice(),1200.0, 0);
        assertEquals(rc.getRAddress(),"G-10 Markaz");
        assertEquals(rc.getRContactNumber(),"03352378242");
        assertEquals(rc.getRegDate(),"2007-07-12");
        assertEquals(rc.getRegisterBy(),"Mehtab");
        assertEquals(rc.getRName(),"Teerath");
        assertEquals(rc.getStatus(),"Pending");
        assertEquals(rc.getType(),"gift");
        assertEquals(rc.generateID(),"R00000000000010");
        rc.setAll("Teerath", "G-10 Markaz","03352378242", 1200.0, "gift", 15, "1", "Mehtab", "C00002"); 
        rc.setAll("C00001","Teerath","G-10 Markaz","03352378242", "gift",12.0, 1200.0, "Mehtab", "C00001");
		rc.setSwap(false);
		assertEquals(rc.generateID(),"R00000000000000");
	    rc.setAll("Teerath", "G-10 Markaz","03352378242", 1200.0, "gift", 15, "1", "Mehtab", "C00002");
	    assertEquals(rc.insertValue(), "('R00000000000001','Teerath','G-10 Markaz','03352378242', null ,1200.0,'gift', 15.0,'Pending','Mehtab','C00002')");
	    assertEquals(e.addCourier(rc),true);
	    assertEquals(e.updateCourier(rc),true);
	    
	    UnRegisteredCourier UC=new UnRegisteredCourier();
	    UC.setAll("C00001", "Teerath", "G-10 Markaz","03352378242", "Mehtab","Rai","G-10 Markaz","03352378242","3520288854061",1200.0, "gift", 15.0,  "Affan");
	    assertEquals(UC.getPrice(),1200.0,0);
	    assertEquals(UC.getCID(),"C00001");
	    assertEquals(UC.getRAddress(),"G-10 Markaz");
	    assertEquals(UC.getRContactNumber(),"03352378242");
	    assertEquals(UC.getRName(),"Teerath");
	    assertEquals(UC.getSender(),"Mehtab Rai");
	    assertEquals(UC.getType(),"gift");
	    assertEquals(UC.getWeight(),15.0,0);
	    assertEquals(UC+"",UC.toString());
	    UC.setRegDate();
	    java.sql.Date utildat = new java.sql.Date(Calendar.getInstance().getTime().getTime());
	    assertEquals(UC.getRegDate(),  utildat.toString());
	    UC.setAll("Teerath", "G-10 Markaz","03352378242", utildat, 1200.0,"gift",15.0,"Pending","Mehtab","Affan", "Ali","G-10 Markaz","03352378242","3520288854061");
	    assertEquals(UC.generateID(),"U00000000000010");
	    UC.setSwap(false);
	    UC.setAll("Teerath", "G-10 Markaz","03352378242", utildat, 1200.0,"gift",15.0,"Pending","Mehtab","Affan", "Ali","G-10 Markaz","03352378242","3520288854061");
	    assertEquals(UC.generateID(),"U00000000000001");
	    assertEquals(UC.insertValue(),"('U00000000000001','Teerath','G-10 Markaz','03352378242', null ,1200.0,'gift', 15.0,'Pending','Mehtab','Affan','Ali','G-10 Markaz','03352378242','3520288854061')");
	    assertEquals(e.addCourier(UC),true);	    
	    UC.setAll("C00001", "Teerath", "G-10 Markaz","03352378242", "2008-03-12", 1200.0,"gift",15.0,"Pending","Rahi","Mehtab","Rai","G-10 Markaz","03352378242","3520288854061");
	    assertEquals(e.updateCourier(UC),true);
	    
	    f.setSwap(true);
		f.generateID();
		f.setSwap(false);
		f.setStatus(true);
		
		//Courier Model
		CourierModel cModel=new CourierModel("C00001", "Teerath","G-10 Markaz","03352378242", "Rahi" ,"Rahi","gift", "15.0","Pending","Mehtab","Affan","Ali","G-10 Marka","03352378242");
		assertEquals(e.CancelCourier(cModel),true);
		assertEquals(e.getPendingCourier().size()>0, true);
		assertEquals(e.getCourierList(new StringBuilder(),"F00001").size()>0, false);
		ObservableList<CourierModel> ls = FXCollections.observableArrayList();
		ls.add(cModel);
		
		Loan l=new Loan();
		l.setAll("L000001",10000.0 , "Need for study");
		l.setAmount(10000.0);
		l.setDescription("Need for study");
		l.setIssueDate("2018-03-23");
		assertEquals(l.getAmount(),10000.0,0);
		assertEquals(l.getDescription(),"Need for study");
		assertEquals(l.getLID(),"L000001");
		assertEquals(l.insertValue(),"('L000001',10000.0,'2018-03-23','Need for study')");
		assertEquals(e.makeShipment("E00001", "Toyata",ls ),false);
		assertEquals(e.getList("Employee", "EID").size()>0,true);
		l.setSwap(false);
		assertEquals(l.getNewID(),0);
		assertEquals(l.getIssueDate(),"2018-03-23");
		assertEquals(e.requestLoan(l),true);
		
		
		
		
		assertEquals(f.insertValue(),"('F000001','G-10 Markaz Branch','Good one','G-10 MArkaz','03352378242',1)");
		assertEquals(f.generateID()+"","F000001");
		assertEquals(f.getFID(),"F000001");
	    assertEquals(f.getName(),"G-10 Markaz Branch");
	    assertEquals(f.getStatus(),true);
	    f.setStatus(false);
		assertEquals(f.insertValue(),"('F000001','G-10 Markaz Branch','Good one','G-10 MArkaz','03352378242',0)");
	    assertEquals(f+"","F000001,G-10 Markaz Branch,Good one,G-10 MArkaz,03352378242");
		e.setJoiningDate(dat);
		assertEquals(e.getStatus(),true);
		assertEquals(e.getJoiningDate(),new java.sql.Date(currentDate.getTime()));
		f.addEmployee(e);
		assertEquals(f.fireEmployee(e.getEID()),true);
		assertEquals(f.fireEmployee(e.getEID()),false);
		assertEquals(f.addManager(m),1);
		assertEquals(f.FireManager(m.getMID()),true);
		assertEquals(f.FireManager(m.getMID()),false);
		assertEquals(f.updateAllowance(alw),1);
		e.setStatus(false);
		assertEquals(e.getStatus(),false);
		e.setFID(e.getFID());
		assertEquals(e.getFID(),null);
		e.setAll("Teerath", "Kumar","G-10 Markaz","03352378242","3520288854061","1996-02-17","FAST", "Employee" , 55000);
		assertEquals(e.getNewID(),1);
		e.setSwap(false);
		e.setAll("Teerath", "Kumar","G-10 Markaz","03352378242","3520288854061","1996-02-17","FAST", "Employee" , 55000);
		assertEquals(e.getNewID(),0);
		assertEquals(f.updateEmployee(e),true);
		
		
		Rate r=new Rate();
		r.setAll("R00010", "Islamabad", 15000, "Used for food");
		assertEquals(r.getDesc(),"Used for food");
		r.setFID(f.getFID());
		assertEquals(r.getFID(),r.getFID());
		assertEquals(r.getID(),"R00010");
		assertEquals(r.getPrice(),15000,0);
		assertEquals(r.getZone(),"Islamabad");
		assertEquals(r.insertValue(),"('R00010','Islamabad',15000.0,'Used for food','F000001')");
		assertEquals(r.generateID("0005"),"00005");
		r.SetSwap(false);
		assertEquals(r.generateID("00005"),"0001");
		
		
		
		Courier cour=new RegisteredCourier();
		cour.setAll("Courier Islamabad", "G-10 Markaz", "023263232", 23000, "registered", 50, "Teerath Kumar");
		assertEquals(cour.getPrice(),23000,0);
		cour.setStatus("Pending");
		assertEquals(cour.getRAddress(),"G-10 Markaz");
		assertEquals(cour.getRContactNumber(),"023263232");
		assertEquals(cour.getRegDateTime(),cour.getRegDateTime());
		assertEquals(cour.getRegisterBy(),"Teerath Kumar");
		assertEquals(cour.getRName(),"Courier Islamabad");	
		assertEquals(cour.getStatus(),"Pending");
		assertEquals(cour.getType(),"registered");
		assertEquals(cour.getWeight(),50,0);
		assertEquals(cour.toString(),cour+"");
		
		
	}

}
